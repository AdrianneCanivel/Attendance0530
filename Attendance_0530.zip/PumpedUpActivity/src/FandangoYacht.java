
public class FandangoYacht extends Boat {
	
    public FandangoYacht(int speed, String color, double price, String mainSailColor) {
        super(speed, color, price, mainSailColor);
        
    }
}
