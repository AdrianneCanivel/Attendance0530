
public class Main {
	
    public static void main(String[] args) {

    	
        toyotaVIOS toyotaVIOS = new toyotaVIOS(120, "Red", 25000, "All-season");
        U2_Spy_Plane u2SpyPlane = new U2_Spy_Plane(500, "White", 5000000, 80.5);
        FandangoYacht fandangoYacht = new FandangoYacht(30, "Blue", 1000000, "White");

        toyotaVIOS.drive();
        System.out.println("Toyota VIOS speed: " + toyotaVIOS.speed + "\n" + "Toyota VIOS color: " + toyotaVIOS.color +
        		"\n" + "Toyota VIOS price: " + toyotaVIOS.price + "\n" + "Toyota VIOS tire type: " + toyotaVIOS.getTireType() + "\n");

        u2SpyPlane.fly();
        System.out.println("U2 Spy Plane speed: " + u2SpyPlane.speed + "\n" + "U2 Spy Plane color: " + u2SpyPlane.color + "\n"
        		+ "U2 Spy Plane price: " + u2SpyPlane.price + "\n" + "U2 Spy Plane wingspan: " + u2SpyPlane.getWingspan() + "\n");

        fandangoYacht.floatOnWater();
        System.out.println("Fandango Yacht speed: " + fandangoYacht.speed + "\n" + "Fandango Yacht color: " + fandangoYacht.color
        + "\n" + "Fandango Yacht price: " + fandangoYacht.price + "\n" + "Fandango Yacht main sail color: " + fandangoYacht.getMainSailColor());
    
    }
}

