
public class Boat extends Vehicle {
	
    private String mainSailColor;

    public Boat(int speed, String color, double price, String mainSailColor) {
        super(speed, color, price);
        this.setMainSailColor(mainSailColor);
    }

    public void floatOnWater() {
        System.out.println("Boat is floating on water.");
        
    }

	public String getMainSailColor() {
		return mainSailColor;
	}

	public void setMainSailColor(String mainSailColor) {
		this.mainSailColor = mainSailColor;
	}
}

