
public class U2_Spy_Plane extends Plane {
	
    public U2_Spy_Plane(int speed, String color, double price, double wingspan) {
        super(speed, color, price, wingspan);
    }
}

