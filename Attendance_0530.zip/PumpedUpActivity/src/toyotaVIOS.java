
public class toyotaVIOS extends Car {
	
    public toyotaVIOS(int speed, String color, double price, String tireType) {
        super(speed, color, price, tireType);
    }
}

