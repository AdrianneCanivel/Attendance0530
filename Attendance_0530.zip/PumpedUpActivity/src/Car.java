
public class Car extends Vehicle {
	
    private String tireType;

    public Car(int speed, String color, double price, String tireType) {
        super(speed, color, price);
        this.setTireType(tireType);
    }

    @Override
    public void stop() {
        System.out.println("Car stopped.");
    }

    public void drive() {
        System.out.println("Car is being driven.");
    }

	public String getTireType() {
		return tireType;
	}

	public void setTireType(String tireType) {
		this.tireType = tireType;
	}
}
