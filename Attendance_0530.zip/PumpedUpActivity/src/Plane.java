
public class Plane extends Vehicle {
	
    private double wingspan;

    public Plane(int speed, String color, double price, double wingspan) {
        super(speed, color, price);
        this.setWingspan(wingspan);
    }

    public void fly() {
        System.out.println("Plane is flying.");
    }

	public double getWingspan() {
		return wingspan;
	}

	public void setWingspan(double wingspan) {
		this.wingspan = wingspan;
	}
}
